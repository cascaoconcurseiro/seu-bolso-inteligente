// Re-export do contexto para manter compatibilidade
export { useTransactionModal } from '@/contexts/TransactionModalContext';

