import { TransactionForm } from '@/components/transactions';

export function NewTransaction() {
  return <TransactionForm />;
}
